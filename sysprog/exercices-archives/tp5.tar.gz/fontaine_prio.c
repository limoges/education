/**
 * Fichier de base pour l'exercice de la fontaine avec priorités.
 */

#define NB_ROBINETS 2
#define NB_OMBRE 4

#include "utilitaires.c"

#define MSG_ARRIVE  "%2d: %c arrive avec %2d seaux     "
#define MSG_SERVI   "%2d: %c est servi... il s'en va  "

int main()
{
  return 0;
}
